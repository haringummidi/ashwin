package com.bnym.gsl.dataloadpoc.job;

import com.bnym.gsl.dataloadpoc.processor.CustomerProcessor;
import com.bnym.gsl.dataloadpoc.entity.Customer;
import com.bnym.gsl.dataloadpoc.reader.GenericCsvReader;
import com.bnym.gsl.dataloadpoc.writer.GenericExcelWriter;
import lombok.AllArgsConstructor;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@AllArgsConstructor
public class CsvtoExcelJob {

    private final GenericCsvReader<Customer> genericReader;
    private final GenericExcelWriter<Customer> genericExcelWriter;

    @Bean
    public FlatFileItemReader<Customer> reader() {
        return genericReader.reader(
                Customer.class,                              // Class type
                "src/main/resources/customers.csv",        // File path
                new String[]{"id", "firstName", "lastName", "email", "gender", "contactNo", "country", "dob"} // Column names
        );
    }

    @Bean
    public ItemWriter<Customer> writer() {
        return genericExcelWriter.excelItemWriter();
    }

    @Bean
    public Step step1(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new StepBuilder("csv-excel-step", jobRepository)
                .<Customer, Customer>chunk(100, transactionManager)
                .reader(reader())
                .processor(new CustomerProcessor())
                .writer(writer())
//                .taskExecutor(taskExecutor())
                .build();
    }

    @Bean
    public Job runJob(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new JobBuilder("importData", jobRepository)
                .flow(step1(jobRepository, transactionManager))
                .end()
                .build();
    }

    @Bean
    public TaskExecutor taskExecutor() {
        SimpleAsyncTaskExecutor asyncTaskExecutor = new SimpleAsyncTaskExecutor();
        asyncTaskExecutor.setConcurrencyLimit(10);
        return asyncTaskExecutor;
    }
}
