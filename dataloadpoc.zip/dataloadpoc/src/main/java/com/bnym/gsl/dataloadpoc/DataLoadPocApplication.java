package com.bnym.gsl.dataloadpoc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataLoadPocApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataLoadPocApplication.class, args);
	}

}
