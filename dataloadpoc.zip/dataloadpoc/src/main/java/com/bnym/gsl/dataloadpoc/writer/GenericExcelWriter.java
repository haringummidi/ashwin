package com.bnym.gsl.dataloadpoc.writer;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;

import java.io.FileOutputStream;
import java.lang.reflect.Field;
import java.util.UUID;

@Component
public class GenericExcelWriter<T> {

    public ItemWriter<T> excelItemWriter() {
        return new ItemWriter<T>() {
            @Override
            public void write(Chunk<? extends T> chunk) throws Exception {
                String fileName = "src/main/resources" + "/output_" + System.currentTimeMillis() + "_" + UUID.randomUUID() + ".xlsx";

                Workbook workbook = new XSSFWorkbook();
                Sheet sheet = workbook.createSheet("Sheet1");

                // Create Header Row
                Row headerRow = sheet.createRow(0);
                Field[] fields = chunk.getItems().get(0).getClass().getDeclaredFields();
                for (int colIdx = 0; colIdx < fields.length; colIdx++) {
                    headerRow.createCell(colIdx).setCellValue(fields[colIdx].getName());
                }

                // Populate Data Rows
                int rowIdx = 1;
                for (T item : chunk) {
                    Row row = sheet.createRow(rowIdx++);
                    int colIdx = 0;
                    for (Field field : fields) {
                        field.setAccessible(true);
                        Object value = field.get(item);
                        row.createCell(colIdx++).setCellValue(value != null ? value.toString() : "");
                    }
                }

                // Write the file to disk
                try (FileOutputStream fos = new FileOutputStream(fileName)) {
                    workbook.write(fos);
                } finally {
                    workbook.close();
                }

                System.out.println("Data successfully written to " + fileName);
            }
        };
    }
}