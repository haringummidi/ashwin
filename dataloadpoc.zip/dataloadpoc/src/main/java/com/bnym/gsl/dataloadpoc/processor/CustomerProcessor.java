package com.bnym.gsl.dataloadpoc.processor;

import com.bnym.gsl.dataloadpoc.entity.Customer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.context.annotation.Configuration;

public class CustomerProcessor implements ItemProcessor<Customer,Customer> {
    @Override
    public Customer process(Customer customer) throws Exception {
        //Filtering the job
//        if (customer.getCountry().equals("United States")) {
//            return customer;
//        } else {
//            return null;
//        }
        return customer;
    }
}