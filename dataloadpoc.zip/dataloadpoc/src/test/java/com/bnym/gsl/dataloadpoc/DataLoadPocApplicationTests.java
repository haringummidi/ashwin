package com.bnym.gsl.dataloadpoc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataLoadPocApplicationTests {

	@Test
	void contextLoads() {
	}

}
